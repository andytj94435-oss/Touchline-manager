# Touchline Manager (Android)

A native Android football management prototype using Java and Android built-in UI components. The repository includes a GitHub Actions workflow to build a debug APK in the cloud, so you can use an Android phone without installing Android Studio.

## Build the APK using only your phone

1. Download and extract this project ZIP.
2. In your phone browser, visit https://github.com and sign in or create an account.
3. Create a **public** repository named `touchline-manager` (public is the easiest way to use GitHub Actions on a free account; you can make it private if your account's Actions allowance permits).
4. Upload the extracted project files and folders to the repository. Make sure the `.github/workflows/build-apk.yml` file is included. GitHub's web uploader may hide dot-folders; if it does, use the GitHub mobile website's upload flow or an Android archive/file app that shows hidden files.
5. Open the repository's **Actions** tab, select **Build Touchline Manager APK**, and tap **Run workflow**. If Actions are disabled, enable them in the repository's Actions settings.
6. Wait for the run to finish successfully. Open that run, find **Artifacts**, and download `touchline-manager-debug-apk`.
7. Extract the artifact ZIP on your phone. Tap `app-debug.apk` to install it. Android may ask you to allow your browser or file manager to install unknown apps.

## Local build (optional)

Open the project in Android Studio and run `gradle assembleDebug` or use **Build > Build APK(s)**. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- This is a debug APK for personal testing, not a Play Store release.
- The game uses fictional clubs and players.
- Cloud build requires a GitHub account and a successful Actions run.
