package com.touchlinemanager.game;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    int navy=Color.rgb(13,29,48), panel=Color.rgb(23,43,64), blue=Color.rgb(16,47,88), pale=Color.rgb(214,229,244), muted=Color.rgb(170,196,221), green=Color.rgb(42,143,79);
    LinearLayout root, content, nav;
    String page="Home", formation="4-4-2", mentality="Balanced", training="Balanced";
    int day=1, budget=42500, morale=70, points=0, played=0, wins=0, draws=0, losses=0;
    boolean matchPlayed=false;
    String lastResult="No matches played yet";
    ArrayList<Player> squad=new ArrayList<>();
    ArrayList<String> inbox=new ArrayList<>();
    ArrayList<String> results=new ArrayList<>();
    HashSet<String> lineup=new HashSet<>();
    Random random=new Random();
    class Player {
        String name,pos; int rating,age,wage;
        Player(String n,String p,int r,int a,int w){name=n;pos=p;rating=r;age=a;wage=w;}
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(blue);getWindow().setNavigationBarColor(navy);
        load();
        if(squad.isEmpty()) initGame();
        render();
    }
    void initGame(){
        String[][] data={{"Jack Mercer","GK","58","26","650"},{"Lewis Grant","RB","55","23","450"},{"Tom Bradley","CB","61","29","700"},{"Aaron Mills","CB","57","25","500"},{"Ben Carter","LB","54","21","350"},{"Sam Fletcher","CM","60","27","600"},{"Ryan Hughes","CM","56","24","450"},{"Ethan Cole","AM","63","22","750"},{"Noah Price","RW","57","20","400"},{"Liam Foster","ST","64","28","800"},{"Callum Reed","ST","59","24","550"},{"Oliver Shaw","ST","60","20","500"}};
        for(String[] p:data)squad.add(new Player(p[0],p[1],Integer.parseInt(p[2]),Integer.parseInt(p[3]),Integer.parseInt(p[4])));
        for(int i=0;i<11;i++)lineup.add(squad.get(i).name);
        inbox.add("Board: A mid-table finish would satisfy expectations.");
        inbox.add("Assistant: Ethan Cole looks like a key creative player.");
        inbox.add("Scouting: A young striker is available on a free transfer.");
    }
    void load(){
        android.content.SharedPreferences s=getSharedPreferences("save",0);
        day=s.getInt("day",1);budget=s.getInt("budget",42500);morale=s.getInt("morale",70);points=s.getInt("points",0);played=s.getInt("played",0);
        formation=s.getString("formation","4-4-2");mentality=s.getString("mentality","Balanced");training=s.getString("training","Balanced");
        lastResult=s.getString("last","No matches played yet");
        try{
            JSONArray a=new JSONArray(s.getString("squad","[]"));
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);squad.add(new Player(o.getString("n"),o.getString("p"),o.getInt("r"),o.getInt("a"),o.getInt("w")));}
            JSONArray l=new JSONArray(s.getString("lineup","[]"));for(int i=0;i<l.length();i++)lineup.add(l.getString(i));
            JSONArray m=new JSONArray(s.getString("inbox","[]"));for(int i=0;i<m.length();i++)inbox.add(m.getString(i));
            JSONArray r=new JSONArray(s.getString("results","[]"));for(int i=0;i<r.length();i++)results.add(r.getString(i));
        }catch(Exception ignored){}
    }
    void save(){
        try{
            JSONObject dummy=new JSONObject(); JSONArray a=new JSONArray();
            for(Player p:squad){JSONObject o=new JSONObject();o.put("n",p.name);o.put("p",p.pos);o.put("r",p.rating);o.put("a",p.age);o.put("w",p.wage);a.put(o);}
            JSONArray l=new JSONArray();for(String n:lineup)l.put(n);
            getSharedPreferences("save",0).edit().putInt("day",day).putInt("budget",budget).putInt("morale",morale).putInt("points",points).putInt("played",played)
                .putString("formation",formation).putString("mentality",mentality).putString("training",training).putString("last",lastResult)
                .putString("squad",a.toString()).putString("lineup",l.toString()).putString("inbox",new JSONArray(inbox).toString()).putString("results",new JSONArray(results).toString()).apply();
        }catch(Exception ignored){}
    }
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(8),dp(7),dp(8),dp(7));if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void addText(LinearLayout p,String s,int size,int color,boolean bold){p.addView(text(s,size,color,bold));}
    void card(String title){
        LinearLayout c=column();c.setBackgroundColor(panel);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));content.addView(c,lp);
        TextView h=text(title,17,Color.WHITE,true);h.setBackgroundColor(blue);c.addView(h); 
    }
    void btn(LinearLayout p,String label,Runnable r){
        Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));p.addView(b,new LinearLayout.LayoutParams(-1,-2));b.setOnClickListener(v->r.run());
    }
    void line(LinearLayout p,String s){TextView t=text(s,14,pale,false);p.addView(t); View v=new View(this);v.setBackgroundColor(Color.rgb(48,71,94));p.addView(v,new LinearLayout.LayoutParams(-1,dp(1)));}
    void render(){
        root=column();root.setBackgroundColor(navy);setContentView(root);
        LinearLayout header=row();header.setBackgroundColor(blue);root.addView(header);
        LinearLayout titles=column();titles.addView(text("TOUCHLINE MANAGER",19,Color.WHITE,true));titles.addView(text("LOWER LEAGUE EDITION · DAY "+day,11,muted,false));header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        Button cont=new Button(this);cont.setText("Continue ▶");cont.setTextColor(Color.WHITE);cont.setAllCaps(false);cont.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));header.addView(cont);cont.setOnClickListener(v->advance());
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));LinearLayout outer=column();outer.setPadding(dp(8),dp(5),dp(8),dp(8));scroll.addView(outer);
        HorizontalScrollView hs=new HorizontalScrollView(this);outer.addView(hs);nav=row();hs.addView(nav);
        String[] pages={"Home","Squad","Tactics","Fixtures","League","Transfers","Training","Finances","Inbox"};
        for(String n:pages){Button b=new Button(this);b.setText(n);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setPadding(dp(5),0,dp(5),0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(page.equals(n)?green:panel));nav.addView(b);b.setOnClickListener(v->{page=n;render();});}
        content=column();outer.addView(content);
        switch(page){case "Home":home();break;case "Squad":squadPage();break;case "Tactics":tactics();break;case "Fixtures":fixtures();break;case "League":league();break;case "Transfers":transfers();break;case "Training":trainingPage();break;case "Finances":finances();break;case "Inbox":inboxPage();break;}
        addText(outer,"Saved automatically on this device · Fictional clubs and players",10,muted,false);
    }
    void home(){
        card("CLUB OVERVIEW");addText(content,"Trowbridge Town",22,Color.WHITE,true);line(content,"National League · Season 2026/27");line(content,"League position: "+(played==0?"—":"12th")+"     Points: "+points);line(content,"Board confidence: "+morale+"%");line(content,"Transfer budget: "+money(budget));line(content,"Squad: "+squad.size()+" players");
        card("NEXT FIXTURE");addText(content,"Trowbridge Town vs "+opponent(),19,Color.WHITE,true);line(content,"Home · National League · Day "+day);line(content,lastResult);
        btn(content,"Prepare for match",()->{page="Fixtures";render();});
        card("LATEST INBOX");for(int i=0;i<Math.min(3,inbox.size());i++)line(content,inbox.get(i));
    }
    String money(int n){return "£"+String.format(java.util.Locale.UK,"%,d",n);}
    String opponent(){String[] a={"Westmoor Athletic","Kingsbridge FC","Ashford Rovers","Millchester Town","Northvale United","Redbrook FC"};return a[day%a.length];}
    void squadPage(){
        card("FIRST TEAM · "+lineup.size()+"/11 SELECTED");
        for(Player p:squad){LinearLayout r=row();r.setBackgroundColor(lineup.contains(p.name)?Color.rgb(28,65,91):panel);content.addView(r);TextView n=text(p.name+"\n"+p.age+" yrs · "+money(p.wage)+"/wk",14,Color.WHITE,false);r.addView(n,new LinearLayout.LayoutParams(0,-2,1));r.addView(text(p.pos,13,muted,true));r.addView(text(""+p.rating,17,p.rating>=60?0xff72e5a0:Color.WHITE,true));Button b=new Button(this);b.setText(lineup.contains(p.name)?"IN":"ADD");b.setTextSize(10);r.addView(b);b.setOnClickListener(v->{if(lineup.contains(p.name)){lineup.remove(p.name);}else if(lineup.size()<11)lineup.add(p.name);else Toast.makeText(this,"Starting XI is full",0).show();save();render();});}
    }
    void tactics(){
        card("FORMATION");String[] fs={"4-4-2","4-3-3","4-2-3-1","5-3-2"};for(String f:fs){Button b=new Button(this);b.setText((formation.equals(f)?"✓ ":"")+f);b.setAllCaps(false);content.addView(b);b.setOnClickListener(v->{formation=f;save();render();});}
        card("MENTALITY");for(String m:new String[]{"Defensive","Balanced","Attacking"}){Button b=new Button(this);b.setText((mentality.equals(m)?"✓ ":"")+m);b.setAllCaps(false);content.addView(b);b.setOnClickListener(v->{mentality=m;save();render();});}
    }
    void fixtures(){
        card("MATCH CENTRE");addText(content,"Trowbridge Town vs "+opponent(),20,Color.WHITE,true);line(content,"Formation: "+formation+" · Mentality: "+mentality);line(content,"Starting XI: "+lineup.size()+"/11");
        btn(content,"KICK OFF — TEXT COMMENTARY",()->playMatch());
        if(matchPlayed){card("FULL-TIME COMMENTARY");for(String s:results.subList(Math.max(0,results.size()-7),results.size()))line(content,s);}
        card("RECENT RESULTS");for(int i=results.size()-1;i>=0;i--)line(content,results.get(i));
    }
    void playMatch(){
        if(lineup.size()!=11){new AlertDialog.Builder(this).setTitle("Team selection").setMessage("Choose exactly 11 players in Squad before kick-off.").setPositiveButton("OK",null).show();return;}
        int strength=0;for(Player p:squad)if(lineup.contains(p.name))strength+=p.rating;strength/=11;
        int gf=Math.max(0,Math.min(5,(strength-53)/10+random.nextInt(3)+(mentality.equals("Attacking")?1:0)));
        int ga=Math.max(0,Math.min(4,random.nextInt(3)+(mentality.equals("Defensive")?0:1)-(strength>60?1:0)));
        String opp=opponent();String summary="Day "+day+": Trowbridge Town "+gf+"-"+ga+" "+opp;
        played++;if(gf>ga){points+=3;wins++;morale=Math.min(99,morale+5);}else if(gf==ga){points++;draws++;morale=Math.min(99,morale+1);}else{losses++;morale=Math.max(20,morale-5);}
        results.add(summary);lastResult="Last result: "+gf+"-"+ga+" vs "+opp;inbox.add(0,"Match report: "+summary);
        results.add("1' Kick-off. Both teams take their positions.");results.add("23' "+(gf>0?"GOAL! Trowbridge find a breakthrough.":"A chance goes begging in front of goal."));results.add("45' Half-time. The manager gives instructions.");results.add("68' "+(ga>0?"GOAL for "+opp+". The defence is caught out.":"Trowbridge defend resolutely under pressure."));results.add("90' Full time: "+gf+"-"+ga+".");
        matchPlayed=true;save();render();
    }
    void league(){
        card("NATIONAL LEAGUE · TABLE");String[][] teams={{"Kingsbridge FC","7"},{"Westmoor Athletic","6"},{"Trowbridge Town",""+points},{"Millchester Town","4"},{"Ashford Rovers","3"},{"Redbrook FC","1"}};
        Arrays.sort(teams,(a,b)->Integer.parseInt(b[1])-Integer.parseInt(a[1]));
        line(content,"POS     CLUB                                  PTS");for(int i=0;i<teams.length;i++)line(content,(i+1)+"       "+teams[i][0]+"                       "+teams[i][1]);
        addText(content,"Illustrative league table. Other clubs' results are not yet simulated.",11,muted,false);
    }
    void transfers(){
        card("AVAILABLE PLAYERS");String[][] ps={{"Oliver Shaw","ST","60","18000","500"},{"Dylan Moore","CB","58","12000","450"},{"Harry Ellis","GK","55","6000","300"}};
        for(String[] p:ps){line(content,p[0]+" · "+p[1]+" · Rating "+p[2]);line(content,"Fee "+money(Integer.parseInt(p[3]))+" · Wage "+money(Integer.parseInt(p[4]))+"/wk");btn(content,"SIGN "+p[0],()->{int fee=Integer.parseInt(p[3]);boolean exists=false;for(Player x:squad)if(x.name.equals(p[0]))exists=true;if(exists){Toast.makeText(this,"Already signed",0).show();return;}if(budget<fee){Toast.makeText(this,"Insufficient funds",0).show();return;}budget-=fee;squad.add(new Player(p[0],p[1],Integer.parseInt(p[2]),21,Integer.parseInt(p[4])));inbox.add(0,"Transfer: "+p[0]+" has signed for "+money(fee)+".");save();render();});}
    }
    void trainingPage(){
        card("TRAINING FOCUS");for(String t:new String[]{"Balanced","Attacking","Defensive"}){Button b=new Button(this);b.setText((training.equals(t)?"✓ ":"")+t);b.setAllCaps(false);content.addView(b);b.setOnClickListener(v->{training=t;save();render();});}
        addText(content,"Advance the day to apply training. Selected focus improves matching positions.",13,muted,false);
    }
    void finances(){card("CLUB FINANCES");line(content,"Transfer budget: "+money(budget));int wage=0;for(Player p:squad)wage+=p.wage;line(content,"Weekly wages: "+money(wage));line(content,"Squad size: "+squad.size());line(content,"Matches played: "+played);line(content,"Record: "+wins+" wins · "+draws+" draws · "+losses+" losses");}
    void inboxPage(){card("MANAGER'S INBOX");for(String m:inbox)line(content,m);btn(content,"CLEAR INBOX",()->{inbox.clear();save();render();});}
    void advance(){
        day++;matchPlayed=false;
        for(Player p:squad){if(training.equals("Attacking")&&(p.pos.equals("ST")||p.pos.equals("RW")||p.pos.equals("AM"))&&random.nextInt(5)==0)p.rating=Math.min(99,p.rating+1);if(training.equals("Defensive")&&(p.pos.equals("GK")||p.pos.equals("CB")||p.pos.equals("RB")||p.pos.equals("LB"))&&random.nextInt(5)==0)p.rating=Math.min(99,p.rating+1);}
        inbox.add(0,"Day "+day+": Training completed. "+training+" focus applied.");if(inbox.size()>30)inbox.remove(inbox.size()-1);save();page="Home";render();
    }
    @Override public void onBackPressed(){if(!page.equals("Home")){page="Home";render();}else super.onBackPressed();}
}